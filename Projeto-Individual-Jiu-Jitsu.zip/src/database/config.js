var mysql = require("mysql2");

// CONEXÃO DO BANCO MYSQL SERVER
var mySqlConfig = {
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT
};

// "valores" é opcional: quando informado, substitui cada ? da instrução SQL

// script antigo (AquaTech): função recebia só a instrução SQL
// function executar(instrucao) {

// script novo (TAS): recebe também "valores", que preenchem cada ? do SQL
function executar(instrucao, valores) {

    if (process.env.AMBIENTE_PROCESSO !== "producao" && process.env.AMBIENTE_PROCESSO !== "desenvolvimento") {
        console.log("\nO AMBIENTE (produção OU desenvolvimento) NÃO FOI DEFINIDO EM .env OU dev.env OU app.js\n");
        return Promise.reject("AMBIENTE NÃO CONFIGURADO EM .env");
    }

    return new Promise(function (resolve, reject) {
        var conexao = mysql.createConnection(mySqlConfig);
        conexao.connect();
         // script antigo (AquaTech):
        // conexao.query(instrucao, function (erro, resultados) {

        // script novo (TAS):
        conexao.query(instrucao, valores, function (erro, resultados) {
            conexao.end();
              // script antigo (AquaTech):
            // if (erro) {
            //     reject(erro);
            // }

            // script novo (TAS): o return impede de seguir para o resolve depois do erro
            if (erro) {
                reject(erro);
                return;
            }
            console.log(resultados);
            resolve(resultados);
        });
        conexao.on('error', function (erro) {
            return ("ERRO NO MySQL SERVER: ", erro.sqlMessage);
        });
    });
}

module.exports = {
    executar
};
